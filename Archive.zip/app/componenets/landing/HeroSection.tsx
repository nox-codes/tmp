import Link from "next/link"
import ScrollReveal from "../scrollReveal"

export default function HeroSection() {
  return (
    <section className="hero-section">
      <div className="hero-bg-gradient" />
      <div className="hero-glow" />
      <div className="section-container hero-content">
        <ScrollReveal>
          <div className="hero-badge">
            <span className="h-1.5 w-1.5 rounded-full bg-brand"></span>
            Built for UNILAG Students
          </div>
        </ScrollReveal>

        <ScrollReveal>
          <h1 className="hero-heading">
            Lock Into Your University's{" "}
            <span className="hero-heading-accent">Resources With Ease</span>
          </h1>
        </ScrollReveal>

        <ScrollReveal>
          <p className="hero-subtext">
            Access curated course materials, practice past questions with CBT simulation,
            track your academic performance, and study smarter — all in one platform
            designed specifically for UNILAG students.
          </p>
        </ScrollReveal>

        <ScrollReveal>
          <div className="hero-cta-group">
            <Link href="/register" className="btn btn-primary">
              Get Started Free
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Link>
            <Link href="/pricing" className="btn btn-secondary">
              View Pricing
            </Link>
          </div>
        </ScrollReveal>

        <ScrollReveal>
          <div className="hero-mockup">
            <div className="hero-mockup-card">
              <div className="hero-mockup-header">
                <span className="hero-mockup-title">{`📊`} Your Study Dashboard</span>
                <span className="inline-flex items-center gap-1.5 rounded-full bg-brand/10 px-3 py-1 text-xs font-medium text-brand">
                  <span className="h-1.5 w-1.5 rounded-full bg-brand animate-pulse-soft"></span>
                  Live
                </span>
              </div>
              <div className="hero-mockup-stats">
                <div className="hero-stat">
                  <p className="hero-stat-value">94%</p>
                  <p className="hero-stat-label">Course Score</p>
                </div>
                <div className="hero-stat">
                  <p className="hero-stat-value">12</p>
                  <p className="hero-stat-label">Day Streak</p>
                </div>
                <div className="hero-stat">
                  <p className="hero-stat-value">248</p>
                  <p className="hero-stat-label">Questions Done</p>
                </div>
                <div className="hero-stat">
                  <p className="hero-stat-value">4.9</p>
                  <p className="hero-stat-label">{`★ `}Rating</p>
                </div>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </div>
    </section>
  )
}