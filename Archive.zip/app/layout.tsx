import type { Metadata } from "next";
import "./globals.css";
import DynamicNav from "./componenets/dynamicNav";
import ConditionalSideBar from "./componenets/conditionalSideBar";

export const metadata: Metadata = {
  title: "UniLock — Lock into your university's resources with ease.",
  description: "Access curated course materials, practice past questions with CBT simulation, track your academic performance, and study smarter — all in one platform designed for UNILAG students.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-screen flex flex-col antialiased">
        <DynamicNav />
        <div className="flex flex-1">
          <ConditionalSideBar />
          <main className="flex-1 w-full">{children}</main>
        </div>
      </body>
    </html>
  );
}